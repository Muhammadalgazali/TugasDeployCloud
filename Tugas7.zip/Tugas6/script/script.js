//Fungsi rubah kata
function rubahKata() {

    //Mendeklarasikan Variable Text dari item be-ID "Text"
    var text = document.getElementById("text");

    //kondisi jika tulisan .. carier dirubah ke .. passion
    if (text.innerHTML === "Cyber Security as Carier") {
      text.innerHTML = "Cyber Security as Passion";
    
    //kondisi jika tulisan .. passion dirubah ke .. hobbies
    }else if (text.innerHTML === "Cyber Security as Passion") {
        text.innerHTML = "Cyber Security as Hobbies";
    
    //kondisi jika tulisan .. hobbies dirubah ke .. education
    }else if (text.innerHTML === "Cyber Security as Hobbies") {
        text.innerHTML = "Cyber Security as Education";
    
    //kondisi selain yang ditetapkan diatas
    } else {
      text.innerHTML = "Cyber Security as Carier";
    }
  }